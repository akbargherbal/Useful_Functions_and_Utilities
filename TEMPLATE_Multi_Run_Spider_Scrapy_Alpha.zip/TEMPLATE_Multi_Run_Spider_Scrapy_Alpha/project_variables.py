path_to_urls_df = 'PATH'

allowed_domains = ['ALLOWED_DOMAINS']

xpath_content = 'XPATH'

time_delay = 0.3

sample = True

if sample:
    batch_size = 25
else:
    batch_size = 5000
