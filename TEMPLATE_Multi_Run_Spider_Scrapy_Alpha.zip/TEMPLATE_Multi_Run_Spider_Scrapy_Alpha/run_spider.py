import subprocess
import pandas as pd
from datetime import datetime
import math
import regex as re
from pathlib import Path

from project_variables import batch_size, time_delay, sample, path_to_urls_df, allowed_domains, xpath_content


# check_list
print('Before you begin scraping; have you checked the following:')
input(f'1) Allowed Domains {allowed_domains}')
input(f'2) Correct Pandas DataFrame of URLS {path_to_urls_df} ?')
input(f'3) Batch size {batch_size}')
input(F'''4) Correct XPATHS?
{xpath_content}
''')
input(f'5) Correct Download Delay {time_delay}')


unix_time = datetime.now().timestamp()

# Get string representation of unix_time
unix_time = str(unix_time)
print(unix_time, type(unix_time))


unix_time = unix_time.split('.')[0]
output_folder = f'output_{unix_time}'

# Create output directory with unix_time as name

Path(output_folder).mkdir(exist_ok=True)


if time_delay == 0:
    print('Be careful you have not set the DOWNLOAD_DELAY in the project_variables.py file')
    print('Would you like to continue? Type YES or NO')
    user_input = input()

    while user_input.upper()  not in ['YES', 'NO']:
        print('Type YES or NO')
        user_input = input()
    
    if user_input.upper() == 'NO':
        print('Exiting...')
        exit()
    


df = pd.read_pickle(path_to_urls_df)

if sample:
    df = df.head(100).reset_index(drop=True)

df_len = len(df)

print(f'Length of DataFrame: {df_len}')


batch_size = int(batch_size)

splits = math.ceil(df_len / batch_size)
splits = [i for i in range(splits)]

print(f'Total Number of Batches: {len(splits)}')

print(f'Total Number of URLs: {df_len}')
spider_name = "poem_01"


spider_configs = [
    (i, f"./{output_folder}/data_{str(i+1).zfill(2)}.json", f"./{output_folder}/LOG_{str(i+1).zfill(2)}.log") for i in splits
]

for config in spider_configs:
    low_limit, output_file, log_name = config
    command = f"scrapy crawl {spider_name} -a low_limit={low_limit} -a log_name={log_name} -o {output_file}"
    print(command)
    print('='*20)
    subprocess.run(command, shell=True)
