import scrapy
import regex as re
import logging
from logging import FileHandler
import pandas as pd
from project_variables import batch_size, path_to_urls_df, allowed_domains, xpath_content, sample


# Now you can use the batch_size variable in this file
print(f"The batch size is: {batch_size}")
print(f"The path to the URLs dataframe is: {path_to_urls_df}")
path_to_urls_df = path_to_urls_df
df = pd.read_pickle(path_to_urls_df)
if sample:
    df = df.head(100).reset_index(drop=True)
df = df.URLS.tolist()


# Configure logging
log_format = "%(asctime)s %(levelname)s %(message)s"
log_date_format = "%Y-%m-%d %H:%M:%S"
logging.basicConfig(
    format=log_format,
    datefmt=log_date_format,
    level=logging.INFO
)
logger = logging.getLogger(__name__)




# Trying to disable logging
logging.getLogger('scrapy').setLevel(logging.WARNING)
logging.getLogger('scrapy').propagate = False
logging.getLogger('scrapy.utils').propagate = False



print(f'''
Allowed Domains: {allowed_domains}
XPATHS: {xpath_content}
Batch Size: {batch_size}
''')
class PoemSpider(scrapy.Spider):
    name = 'poem_01'
    allowed_domains = allowed_domains


    custom_settings = {
    	"LOG_LEVEL": 'WARNING',
    }
    def __init__(self, low_limit=None, log_name=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.log_name = log_name
        self.low_limit = int(low_limit) * batch_size
        self.high_limit = self.low_limit + batch_size
        self.start_urls = df[self.low_limit : self.high_limit]
        print(f'Total Number of URLs: {len(self.start_urls)}')

        if self.log_name:
            file_handler = FileHandler(self.log_name)
            file_handler.setFormatter(logging.Formatter(log_format, datefmt=log_date_format))
            logger.addHandler(file_handler)

        logger.info(f'Total Number of URLs: {len(self.start_urls)}')            
        

    def start_requests(self):
        logger.info(f"low_limit: {self.low_limit}, high_limit: {self.high_limit}")
        logger.info(f"{'@'*10}")
        for url in self.start_urls:
            yield scrapy.Request(url, self.parse)
    def parse(self, response):
        try:
            url = response.url
            content = response.xpath(xpath_content).getall()
            yield {
                'CONTENT': content,
                'URL': url
            }

            logger.info(f"URL: {url}")
        except Exception as e:
            logger.info(f"{'#'*10}")
            logger.error(f"Error: {e}")
            logger.info(f"{'#'*10}")