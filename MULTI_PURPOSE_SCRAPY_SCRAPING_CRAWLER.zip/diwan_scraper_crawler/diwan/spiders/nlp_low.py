import scrapy

class PoemSpider(scrapy.Spider):
    name = 'nlp_low'
    start_urls = [f"https://libraries.io/search?keywords=nlp&languages=Python&page={i}&sort=stars" for i in range(1,47)]

    def parse(self, response):
        packages = response.xpath('//div[@class="project"]').getall()

        yield {

            'PACKAGES': packages,
            'URL': response.url
        }